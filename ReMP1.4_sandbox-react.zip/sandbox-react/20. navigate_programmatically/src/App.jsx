import * as React from 'react';
import { browserHistory as history } from 'react-router';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><button onClick={() => history.push('/')}>Home</button></li>
                    <li><button onClick={() => this.context.router.push('/about/company/employees')}>About</button></li>
                    <li><button onClick={() => history.replace('/posts')}>Posts</button></li>
                    <li><button onClick={() => history.push('/posts?search=typescript&label=important')}>Posts with filter in url</button></li>
                    <li>
                        <button
                            onClick={() =>
                                history.push(this.context.router.createPath({ pathname: "/posts", query: { "search": "typescript", label: 'important' } }))
                            }>
                            Posts with filter
                        </button>
                    </li>
                    <li><button onClick={() => history.push('/posts/article/TypeScript')}>Article</button></li>
                </ul>

                {this.props.children}
            </div>
        );
    }
}

App.contextTypes = {
    router: React.PropTypes.object
}