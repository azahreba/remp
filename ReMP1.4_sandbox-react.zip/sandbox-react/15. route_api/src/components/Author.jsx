import * as React from 'react';

export class Author extends React.Component {

    render() {
        return (
            <p>Author</p>
        );
    }
}
