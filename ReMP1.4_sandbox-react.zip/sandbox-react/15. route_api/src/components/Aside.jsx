import * as React from 'react';

export class Aside extends React.Component {

    render() {
        return (
            <p>Aside</p>
        );
    }
}
