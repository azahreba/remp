import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';
import { NotFound } from './NotFound';
import { Aside } from './components/Aside';
import { Author } from './components/Author';

ReactDom.render((
    <Router history={browserHistory}>

        <Route path="/" component={App}>

            <Route path="posts" component={Posts}>
                <Route path="main" components={{ author: Author, aside: Aside }} />
            </Route>

            <Route
                path="about"
                component={About}
                onEnter={(nextState, replace, callback) => {
                    console.log('onEnter', nextState);
                    //replace('/posts/0/1');
                    callback();
                } }

                onChange={(prevState, nextState, replace, callback) => {
                    console.log('onChange', prevState, nextState);
                    callback();
                } }

                onLeave={prevState => {
                    console.log('onLeave', prevState);
                } }
                />

            <Route path="*" component={NotFound} />

        </Route>
    </Router>
), document.getElementById('app'));