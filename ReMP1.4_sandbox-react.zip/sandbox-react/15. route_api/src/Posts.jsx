import * as React from 'react';

export class Posts extends React.Component {

    render() {
        return (
            <div>
                Posts
                {this.props.aside}
                {this.props.author}
            </div>
        );
    }
}