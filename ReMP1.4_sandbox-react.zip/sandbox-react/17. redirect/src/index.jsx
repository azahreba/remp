import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, Redirect, IndexRedirect, browserHistory } from 'react-router';
import { App } from './App';
import { Welcome } from './Welcome';
import { About } from './About';
import { Posts } from './Posts';
import { Article } from './Article';
import { List } from './List';
import { NotFound } from './NotFound';

ReactDom.render((
    <Router history={browserHistory}>
        <Route path="/" component={App}>

            <IndexRoute component={Welcome} />

            <Route path="posts" component={Posts}>
                <IndexRoute component={List} />
                <Route path="article/:name" component={Article} />
                <Redirect from="story/:name" to="article/:name" />
            </Route>

            <Route path="about">
                <IndexRedirect to="products/featured" />
                <Route path=":tab/:section" component={About} />
            </Route>

            <Redirect from="workers" to="about/company/employees" />

            <Route path="*" component={NotFound} />

        </Route>
    </Router>
), document.getElementById('app'));