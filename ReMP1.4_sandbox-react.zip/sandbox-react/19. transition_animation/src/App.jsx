import * as React from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group'
import { Link } from 'react-router';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/about/company/employees">About</Link></li>
                    <li><Link to="/posts">Posts</Link></li>
                    <li><Link to="/posts/article/TypeScript">Article</Link></li>
                </ul>

                <ReactCSSTransitionGroup
                    transitionName="page"
                    transitionEnterTimeout={1000}
                    transitionLeaveTimeout={1000}
                    >
                    {React.cloneElement(this.props.children, {
                        key: location.pathname
                    })}
                </ReactCSSTransitionGroup>
            </div>
        );
    }
}