import * as React from 'react';

export class About extends React.Component {

    componentDidMount() {
        this.context.router.setRouteLeaveHook(this.props.route, () => 'Do you want leave us?');
    }

    render() {
        return (
            <p>About</p>
        );
    }
}

About.contextTypes = {
    router: React.PropTypes.object
};
