import * as React from 'react';
import { Link, IndexLink } from 'react-router';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><IndexLink to="/" activeStyle={{ color: 'red' }}>Home</IndexLink></li>
                    <li><Link to="/about" activeClassName="active_link">About</Link></li>
                    <li><Link to={{ pathname: '/posts' }} activeStyle={{ color: 'green' }}>Posts</Link></li>
                </ul>

                <div>
                    <button onClick={() => this.props.router.push({ pathname: '/posts' })}>Push</button>
                    <button onClick={() => this.props.router.replace({ pathname: '/about' })}>Replace</button>
                    <button onClick={() => this.props.router.go(2)}>go</button>
                    <button onClick={() => this.props.router.goBack()}>goBack</button>
                    <button onClick={() => this.props.router.goForward()}>goForward</button>
                </div>

                {this.props.router.isActive('/about') && <div>Don't leave us!!</div>}

                {this.props.children}
            </div >
        );
    }
}