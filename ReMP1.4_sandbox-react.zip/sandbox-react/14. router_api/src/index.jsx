import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';
import { NotFound } from './NotFound';

ReactDom.render((
    <Router
        history={browserHistory}
        onUpdate={() => console.log('updated', arguments)}
        createElement={(Component, props) => <div className="wrapper"><Component {...props} /></div>}
        >

        <Route path="/" component={App}>
            <Route path="posts" component={Posts} />
            <Route path="about" component={About} />
            <Route path="*" component={NotFound} />
        </Route>

    </Router>
), document.getElementById('app'));