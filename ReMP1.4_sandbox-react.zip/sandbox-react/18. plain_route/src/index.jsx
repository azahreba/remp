import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, Redirect, IndexRedirect, browserHistory } from 'react-router';
import { App } from './App';
import { Welcome } from './Welcome';
import { About } from './About';
import { Posts } from './Posts';
import { Article } from './Article';
import { List } from './List';
import { NotFound } from './NotFound';

const routes = {
    path: '/',
    component: App,
    indexRoute: { component: Welcome },
    childRoutes: [
        {
            path: 'posts',
            component: Posts,
            indexRoute: { component: List },
            childRoutes: [
                { path: 'article/:name', component: Article },
                { path: 'story/:name', onEnter: (nextState, replace) => replace(`/posts/article/${nextState.params.name}`) },
            ]
        },
        {
            path: 'about',
            indexRoute: { onEnter: (nextState, replace) => replace(`/about/products/featured`) },
            childRoutes: [
                { path: ':tab/:section', component: About }
            ]
        },
        {
            path: 'workers',
            onEnter: (nextState, replace) => replace(`/about/company/employees`)
        },
        {
            path: '*',
            component: NotFound
        }
    ]
};

ReactDom.render((
    <Router history={browserHistory} routes={routes} />
), document.getElementById('app'));
