import * as React from 'react';

export class List extends React.Component {

    render() {
        return (
            <div>Articles list</div>
        );
    }
}