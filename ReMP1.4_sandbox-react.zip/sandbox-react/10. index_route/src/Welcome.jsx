import * as React from 'react';

export class Welcome extends React.Component {

    render() {
        return (
            <p>Welcome!</p>
        );
    }
}