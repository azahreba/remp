import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, hashHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';

ReactDom.render((
    <Router history={hashHistory}>
        <Route path="/" component={App}>
            <Route path="posts" component={Posts} />
            <Route path="about" component={About} />
        </Route>
    </Router>
), document.getElementById('app'));