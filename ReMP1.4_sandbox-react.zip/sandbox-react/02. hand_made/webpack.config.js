const path = require('path');

module.exports = {

    context: path.join(__dirname, 'src'),

    entry: './index.jsx',

    output: {
        filename: 'bundle.js',
        path: path.join(__dirname, './built'),
        publicPath: '/built/'
    },

    resolve: {
        extensions: ['', '.js', '.jsx']
    },

    module: {
        loaders: [
            {
                loader: "babel-loader",

                // Skip any files outside of your project's `src` directory
                include: [
                    path.resolve(__dirname, "src"),
                ],

                // Only run `.js` and `.jsx` files through Babel
                test: /\.jsx?$/,

                // Options to configure babel with
                query: {
                    presets: ['latest', 'react'],
                }
            },
        ],
    },

    devServer: {
        inline: true,
        contentBase: './'
    },
};
