import * as React from 'react';
import { About } from './About';
import { Posts } from './Posts';

export class App extends React.Component {

    componentWillMount() {
        this.props.history.listen(() => this.forceUpdate());
    }

    transit(to, event) {
        event.preventDefault();
        this.props.history.push(to);
    }

    renderContent() {
        switch (this.props.history.location.pathname) {
            case '/about':
                return <About />
            case '/posts':
                return <Posts />
            default:
                return <p>Hello</p>
        }
    }

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><a href="/about" onClick={e => this.transit('/about', e)} >About</a></li>
                    <li><a href="/posts" onClick={e => this.transit('/posts', e)} >Posts</a></li>
                </ul>
                {this.renderContent()}
            </div>
        );
    }
}