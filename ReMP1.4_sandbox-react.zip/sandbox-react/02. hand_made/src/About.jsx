import * as React from 'react';

export class About extends React.Component{

    render(){
        return (
            <p>About</p>
        );
    }
}