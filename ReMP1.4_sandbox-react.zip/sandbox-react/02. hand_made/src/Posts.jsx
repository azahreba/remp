import * as React from 'react';

export class Posts extends React.Component{

    render(){
        return (
            <p>Posts</p>
        );
    }
}