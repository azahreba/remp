import React from 'react';
import * as ReactDom from 'react-dom';
import * as history from 'history';
import { App } from './App';

const hashHistory = history.createHashHistory();

hashHistory.listen((location) => {
    console.log(`The current URL is ${location.pathname}${location.search}${location.hash}`)
})

ReactDom.render((
    <App history={hashHistory} />
), document.getElementById('app'))