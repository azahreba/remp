import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, browserHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';
import { NotFound } from './NotFound';

ReactDom.render((
    <Router history={browserHistory}>
        <Route path="/" component={App}>
            <Route path="posts" component={Posts} />
            <Route path="about" component={About} />
        </Route>
        <Route path="*" component={NotFound} />
    </Router>
), document.getElementById('app'));