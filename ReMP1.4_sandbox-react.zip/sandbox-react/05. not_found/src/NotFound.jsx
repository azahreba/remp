import * as React from 'react';

export class NotFound extends React.Component {

    render() {
        return (
            <p>404 Not found</p>
        );
    }
}