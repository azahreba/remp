import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { App } from './App';
import { Welcome } from './Welcome';
import { About } from './About';
import { Posts } from './Posts';
import { Article } from './Article';
import { List } from './List';
import { NotFound } from './NotFound';

ReactDom.render((
    <Router history={browserHistory}>
        <Route path="/" component={App}>

            <IndexRoute component={Welcome} />

            <Route path="posts" component={Posts}>
                <IndexRoute component={List} />
                <Route path="article/:name" component={Article} />
            </Route>

            <Route path="about/:tab/:section" component={About} />

            <Route path="*" component={NotFound} />

        </Route>
    </Router>
), document.getElementById('app'));