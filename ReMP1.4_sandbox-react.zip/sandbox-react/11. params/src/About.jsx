import * as React from 'react';

export class About extends React.Component {

    render() {
        return (
            <p>About tab: {this.props.routeParams.tab}, and section: {this.props.routeParams.section}</p>
        );
    }
}