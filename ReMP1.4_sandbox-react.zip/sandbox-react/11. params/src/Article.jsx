import * as React from 'react';

export class Article extends React.Component {

    render() {
        return (
            <div>
                <h3>Single post</h3>
                <p>Some article: {this.props.routeParams.name}</p>
            </div>
        );
    }
}