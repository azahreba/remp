import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';

ReactDom.render((
    <Router history={browserHistory}>

        <Route path="/" component={App}>

            <Route path="posts" component={Posts}>

                <Route
                    path="main"
                    getComponents={
                        (nextState, cb) =>
                            require.ensure([],
                                () => cb(null, {
                                    aside: require('./components/Aside').Aside,
                                    author: require('./components/Author').Author
                                })
                            )
                    } />

            </Route>

            <Route path="about" component={About} />

            <Route
                path="*"
                getComponent={(nextState, cb) =>
                    require.ensure([],
                        () => cb(null, require('./NotFound').NotFound)
                    )
                }
                />

        </Route>
    </Router>
), document.getElementById('app'));