import * as React from 'react';
import { Link, IndexLink } from 'react-router';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><IndexLink to="/" activeStyle={{ color: 'red' }}>Home</IndexLink></li>
                    <li><Link to="/about" activeClassName="active_link">About</Link></li>
                    <li><Link to="/wrong/link">404</Link></li>
                    <li><Link to="/about?search=hello" activeClassName="active_link">About with query</Link></li>
                    <li><Link to={{ pathname: '/posts/main' }} activeStyle={{ color: 'green' }}>Posts</Link></li>
                </ul>

                {this.props.children}
            </div >
        );
    }
}