import * as React from 'react';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><a href="/about">About</a></li>
                    <li><a href="/posts">Posts</a></li>
                </ul>

                {this.props.children}
            </div>
        );
    }
}