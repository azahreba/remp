import createBrowserHistory from 'history/createBrowserHistory';
import createHashHistory from 'history/createHashHistory';

let history = null;
let unblock = null;

document.getElementById('modes').addEventListener('change', e => {

    if (e.target.value == 'browserHistory') {
        history = createBrowserHistory();
    } else {
        history = createHashHistory();
    }

    history.listen((location, action) => {
        console.log(`The current URL is ${location.pathname}${location.search}${location.hash}`)
        console.log(`The last navigation action was ${action}`)
    })
});


document.getElementById('log').addEventListener('click', e => {
    console.log(history);
});

document.getElementById('navigation').addEventListener('click', e => {
    if (!history) {
        console.log('Select history');
        return;
    }

    switch (e.target.getAttribute('data-type')) {
        case 'push':
            history.push({
                pathname: `/push/some/page/${Math.round(Math.random() * 1000)}`,
                search: '?the=query',
                state: { some: { one: Math.round(Math.random() * 1000) } }
            });

            break;
        case 'replace':
            history.replace(`/replace/section/${Math.round(Math.random() * 1000)}`);
            break;
        case 'go':
            history.go(1);
            break;
        case 'goBack':
            history.goBack();
            break;
        case 'goForward':
            history.goForward();
            break;
    }

});

document.getElementById('blocking').addEventListener('click', e => {
    if (!history) {
        console.log('Select history');
        return;
    }

    switch (e.target.getAttribute('data-type')) {
        case 'block':
            unblock = history.block('Are you sure you want to leave this page?')
            break;
        case 'unblock':
            unblock();
            break;
    }

});