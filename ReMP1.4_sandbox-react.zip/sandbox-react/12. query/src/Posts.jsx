import * as React from 'react';

export class Posts extends React.Component {

    render() {
        return (
            <div>
                <h2>Posts</h2>
                <div>Search: {this.props.location.query.search}</div>
                <div>Label: {this.props.location.query.label}</div>
                <pre>Filter {JSON.stringify(this.props.location.query)}</pre>
                {this.props.children}
            </div>
        );
    }
}