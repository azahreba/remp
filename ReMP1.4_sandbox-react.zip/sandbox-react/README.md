Snadbox with React Router examples.

To run examples:
	1. `npm install` in this folder
	2. `npm start`
	
Each example is placed on localhost but with deffirent ports:`http://localhost:80[index]` where index is the example number, i.e. if you go to `http://localhost:8007/` you will see `07. link_styling` example.