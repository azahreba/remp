import * as React from 'react';
import { Link, IndexLink } from 'react-router';

export class App extends React.Component {

    render() {
        return (
            <div>
                <h1>App</h1>
                <ul>
                    <li><Link to="/" activeStyle={{ color: 'cyan' }}>Home</Link></li>
                    <li><IndexLink to="/" activeStyle={{ color: 'cyan' }}>Home with index link</IndexLink></li>
                    <li><Link to="/" activeStyle={{ color: 'cyan' }} onlyActiveOnIndex={true}>Home with onlyActiveOnIndex</Link></li>
                    <li><Link to="/about" activeClassName="active_link">About</Link></li>
                    <li><Link to={{ pathname: '/posts' }} activeStyle={{ color: 'green' }}>Posts</Link></li>
                </ul>

                {this.props.children}
            </div>
        );
    }
}