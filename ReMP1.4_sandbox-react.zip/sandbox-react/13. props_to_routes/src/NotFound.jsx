import * as React from 'react';

export class NotFound extends React.Component {

    render() {
        return (
            <p>Error {this.props.route.code}</p>
        );
    }
}