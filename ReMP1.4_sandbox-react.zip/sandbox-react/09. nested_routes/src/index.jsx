import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Router, Route, browserHistory } from 'react-router';
import { App } from './App';
import { About } from './About';
import { Posts } from './Posts';
import { Article } from './Article';
import { NotFound } from './NotFound';

ReactDom.render((
    <Router history={browserHistory}>
        <Route path="/" component={App}>

            <Route path="posts" component={Posts}>
                <Route path="article" component={Article} />
            </Route>

            <Route path="about" component={About} />

            <Route path="*" component={NotFound} />
        </Route>
    </Router>
), document.getElementById('app'));