const fs = require('fs');
const path = require('path');
const webpack = require('webpack');
const WebpackDevServer = require('webpack-dev-server');

function getDirectories(srcpath) {
    return fs.readdirSync(srcpath).filter(function (file) {
        return fs.statSync(path.join(srcpath, file)).isDirectory();
    });
}

const examples = getDirectories('./').filter(d => d[0] != '.' && d != 'node_modules');

examples.forEach(e => {
    try {
        var configPath = `./${e}/webpack.config.js`;

        var config = require(configPath);
        config.devServer.contentBase = e;
        config.devServer.publicPath = '/built/';

        var compiler = webpack(config);
        var server = new WebpackDevServer(compiler, config.devServer);

        var index = e.substring(0, e.indexOf('.'));
        var port = parseInt(`80${index}`);

        server.listen(port, "localhost", () => console.log(`Example "${e}" is running on http://localhost:${port}`));
    } catch (err) {
        console.log(`${e} is not an example`);
    }

});